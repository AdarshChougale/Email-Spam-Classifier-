# Email Spam Classifier

![strmlit-email](https://github.com/Adm-2005/Email-Spam-Classifier/assets/136343806/83f518b4-a0d3-45cf-9f12-736e8d8f9c07)

## Tech Stack
- Libraries:- Pandas, NumPy, Sklearn, Streamlit, NLTK
- Model:- Multinomial Naive Bayes

## Important Links
- GitHub Repo:- [Visit](https://github.com/Adm-2005/Email-Spam-Classifier)
- Live Project:- [Visit](https://email-spam-classifier-f8pp.onrender.com)
